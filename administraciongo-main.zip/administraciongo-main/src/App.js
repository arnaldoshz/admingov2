import React, { useRef, useState } from 'react';
import { GoogleMap, LoadScript, Marker } from '@react-google-maps/api';
import RegistroConductores from './registroconductores'; // Importa el componente de registro
import './App.css'; // Asegúrate de que esta línea esté presente

const mapContainerStyle = {
  height: "100vh",
  width: "100%"
};

const center = {
  lat: 9.5649264, // Cambia a la latitud deseada
  lng: -69.2076527 // Cambia a la longitud deseada
};

// Array de marcadores con latitud y longitud
const markers = [
  { id: 1, position: { lat: 9.5649264, lng: -69.2076527 } }, // Marcador 1
  { id: 2, position: { lat: 9.5700000, lng: -69.2000000 } }, // Marcador 2
  { id: 3, position: { lat: 9.5600000, lng: -69.2100000 } }  // Marcador 3
];

function App() {
  const [showRegistro, setShowRegistro] = useState(false); // Estado para controlar la visualización del registro
  const [isLoaded, setIsLoaded] = useState(false); // Estado para verificar si la API se ha cargado

  const handleRegistroClick = () => {
    setShowRegistro(true); // Muestra el componente de registro
  };

  const handleLoad = () => {
    setIsLoaded(true); // Cambia el estado a verdadero cuando la API se haya cargado
  };

  return (
    <div className="App">
      {showRegistro ? (
        <RegistroConductores /> // Muestra el componente de registro
      ) : (
        <>
          <LoadScript googleMapsApiKey="AIzaSyBEXEiaXcTjsnI4I1rAQtKgpZbqwYygzps" onLoad={handleLoad}>
            <GoogleMap
              mapContainerStyle={mapContainerStyle}
              center={center}
              zoom={15}
            >
              {isLoaded && markers.map(marker => (
                <Marker 
                  key={marker.id} 
                  position={marker.position} 
                  icon={{
                    url: "/carromove.png", // Ruta a la imagen en la carpeta public
                    scaledSize: new window.google.maps.Size(80, 50) // Ajusta el tamaño del ícono
                  }} 
                />
              ))}
            </GoogleMap>
          </LoadScript>
          <header className="App-header">
            <h1 className="header">Registrate Ya </h1> {/* Asegúrate de que tenga la clase 'header' */}
            <div className="logo-box">
              <img src="/logovengo.png" alt="Logo" className="logo-animada" /> {/* Imagen animada debajo de los botones */}
            </div>
            <div className="admin-text">"Cada kilómetro, un placer."</div>
          </header>
          <div className="button-container" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', position: 'absolute', bottom: '120px', left: '50%', transform: 'translateX(-50%)' }}>
            <button className="registro-button modern-button" onClick={handleRegistroClick}>Registro de Conductores</button>
            <button className="registro-button modern-button">Registro de Comercios</button>
            <button className="registro-button modern-button">Registro de Motos</button>
          </div>
        </>
      )}
    </div>
  );
}

export default App;
