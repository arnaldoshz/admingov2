import React, { useRef } from 'react';
import { GoogleMap, LoadScript, Marker } from '@react-google-maps/api';
import './App.css'; // Asegúrate de que esta línea esté presente

const mapContainerStyle = {
  height: "100vh",
  width: "100%"
};

const center = {
  lat: 9.5649264, // Cambia a la latitud deseada
  lng: -69.2076527 // Cambia a la longitud deseada
};

function administracion() {
  const loginRef = useRef(null); // Referencia al formulario de inicio de sesión

  return (
    <div className="App">
      <LoadScript googleMapsApiKey="AIzaSyBEXEiaXcTjsnI4I1rAQtKgpZbqwYygzps"> {/* Reemplaza con tu clave de API */}
        <GoogleMap
          mapContainerStyle={mapContainerStyle}
          center={center}
          zoom={15}
        >
          <Marker position={center} /> {/* Marca la ubicación en el mapa */}
        </GoogleMap>
      </LoadScript>
      <header className="App-header">
        <div className="logo-box">
          <img src="/logovengo.png" alt="Logo" className="logo" /> {/* Ruta actualizada */}
        </div>
        <div className="admin-text">Administración</div>
      </header>
      <div className="login-container" ref={loginRef}>
        <h2>Iniciar Sesión</h2>
        <form>
          <input type="text" placeholder="Usuario" className="login-input" />
          <input type="password" placeholder="Contraseña" className="login-input" />
          <button type="submit" className="login-button">Entrar</button>
        </form>
      </div>
    </div>
  );
}

export default administracion;