import React, { useState } from 'react';
import { GoogleMap, LoadScript, Marker } from '@react-google-maps/api';
import './RegistroConductores.css'; // Asegúrate de tener el CSS para el mapa

const mapContainerStyle = {
  height: "100vh",
  width: "100%"
};

const center = {
  lat: 9.5649264, // Cambia a la latitud deseada
  lng: -69.2076527 // Cambia a la longitud deseada
};

function RegistroConductores() {
  const [isLogin, setIsLogin] = useState(true); // Estado para controlar el modo de inicio de sesión o registro

  const toggleForm = () => {
    setIsLogin(!isLogin); // Cambia entre inicio de sesión y registro
  };

  return (
    <div className="registro-container">
      <header className="App-header">
        <div className="logo-box">
          <img src="/logovengo.png" alt="Logo" className="logo" /> {/* Ruta actualizada */}
        </div>
        <div className="admin-text">Registro de Conductores</div>
      </header>
      <LoadScript googleMapsApiKey="AIzaSyBEXEiaXcTjsnI4I1rAQtKgpZbqwYygzps"> {/* Reemplaza con tu clave de API */}
        <GoogleMap
          mapContainerStyle={mapContainerStyle}
          center={center}
          zoom={15}
        >
          <Marker position={center} /> {/* Marca la ubicación en el mapa */}
          <div className="form-container">
            <h2>{isLogin ? "Iniciar Sesión" : "Registrarse"}</h2>
            <form>
              <input type="text" placeholder="Usuario" className="login-input" />
              <input type="password" placeholder="Contraseña" className="login-input" />
              {!isLogin && <input type="text" placeholder="Nombre Completo" className="login-input" />} {/* Campo adicional para registro */}
              <button type="submit" className="login-button">{isLogin ? "Entrar" : "Registrar"}</button>
            </form>
            <button onClick={toggleForm} className="toggle-button">
              {isLogin ? "¿No tienes una cuenta? Regístrate" : "¿Ya tienes una cuenta? Inicia sesión"}
            </button>
          </div>
        </GoogleMap>
      </LoadScript>
    </div>
  );
}

export default RegistroConductores;
